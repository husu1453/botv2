const Discord = require('discord.js');
exports.run = async (client, message, args) => {
let prefix = '!'
let yardım = new Discord.RichEmbed()
.setAuthor(`${client.user.username}`, client.user.avatarURL)
.setColor('RANDOM')
.setTitle('Botun Davet Bağlantısı')
.setURL('https://discord.com/oauth2/authorize?client_id=738394904962531339&scope=bot&permissions=8')
.setThumbnail("https://media.giphy.com/media/Z9WQLSrsQKH3uBbiXq/giphy.gif")

 message.channel.send(yardım)
  };
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['invite'],
  permLevel: 0
};
exports.help = {
  name: 'invite'
};
