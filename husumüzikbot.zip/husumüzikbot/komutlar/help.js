const Discord = require('discord.js');
exports.run = async (client, message, args) => {
let prefix = '!'
let yardım = new Discord.RichEmbed()
.setAuthor(`${client.user.username}`, client.user.avatarURL)
.setColor('RANDOM')
.addField('Music Bot | Müzik Komutları',`
**!play <şarkıismi>** : Belirttiğiniz Şarkıyı Sesli Odada Söyler
**!stop** : Çalan Şarkıyı Durdurur
**!start** : Durdurduğunuz Şarkıyı Devam Ettirir
**!skip** : Bir Sonraki Şarkıya Geçiş Yapar
**!disconnect** : Botun Bağlantısını Keser
**!çek** : Botu Olduğunuz Kanala Çeker
**!volume** : Ses Seviyesini Belirler`)
.setFooter(`${message.author.tag} Tarafından İstendi.`, message.author.avatarURL)
.setThumbnail("https://media.giphy.com/media/Z9WQLSrsQKH3uBbiXq/giphy.gif")

 message.channel.send(yardım)
  };
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['yardım','hhelp'],
  permLevel: 0
};
exports.help = {
  name: 'müzik'
};
